import{j as r}from"./react-core-8f9897d8.js";import"./vendor-62d4360a.js";const e=()=>r.jsx("div",{children:r.jsx("h1",{children:"PlanDetail"})});export{e as PlanDetail};
